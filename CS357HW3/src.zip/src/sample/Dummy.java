package sample;

public class Dummy {
    public static void main(String[] args) {

        Main.main(args);
    }
}
